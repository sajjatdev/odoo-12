{
    'name': "PFAU Customization",
    'version': '1.0',
    'description': """
    """,
    'depends': ['base', 'purchase', 'sale', 'sale_purchase', 'account'],
    'data': [
        'views/custom.xml',
        'report/custom_quot_report.xml',
        'report/custom_inv_report.xml'
    ],
    'installable': 'True',
}
