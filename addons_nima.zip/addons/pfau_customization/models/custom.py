from odoo import fields, models, api, _
from odoo.exceptions import UserError
from odoo.addons import decimal_precision as dp


class PurchaseLine(models.Model):
    _inherit = 'purchase.order.line'

    description = fields.Text('Description')

    def get_move_name(self):
        product = self.product_id
        name = product.name
        if product.length and product.width:
            name += '\n' + 'Dim.: '
            name += product.length + 'x'
            name += product.width + 'x'
        if product.seating_height:
            name += product.seating_height
        if product.height:
            if product.seating_height:
                name += '/'
        if product.height:
            name += product.height
        if product.seating_height:
            name += ' cm/h'
        if product.description_purchase:
            name += '\n' + product.description_purchase
        return name

    @api.model
    def create(self, vals):
        res = super(PurchaseLine, self).create(vals)
        res.description = res.get_move_name()
        return res


class Product(models.Model):
    _inherit = "product.product"

    price_extra = fields.Float()
    wk_extra_price = fields.Float()
    attr_price_extra = fields.Float()
    attrs_value = fields.Text(string='Attribute Values', compute='_purchase_calculation')
    another_costs = fields.Float(string='Cost')

    @api.depends('attribute_value_ids')
    def _purchase_calculation(self):
        for record in self:
            res = ""
            for docs in record.attribute_value_ids:
                if docs.attribute_id.attr_value:
                    res += "%s: %s \n" % (docs.attribute_id.custom_attr_name, docs.name)
                # a = list(res)
            record.attrs_value = res

    def get_product_multiline_description_sale(self):
        """ Compute a multiline description of this product, in the context of sales
                (do not use for purchases or other display reasons that don't intend to use "description_sale").
            It will often be used as the default description of a sale order line referencing this product.
        """
        name = self.name
        if self.length and self.width:
            name += '\n' + 'Dim.: '
            name += self.length + 'x'
            name += self.width + 'x'
        if self.seating_height:
            name += self.seating_height
        if self.height:
            if self.seating_height:
                name += '/'
        if self.height:
            name += self.height
        if self.seating_height:
            name += ' cm/h'
        if self.description_sale:
            name += '\n' + self.description_sale

        return name


class ProductSupplierInfo(models.Model):
    _inherit = "product.supplierinfo"

    purchase_discount = fields.Float(string='Purchase Discount')
    product_id = fields.Many2one(
        comodel_name='product.product',
        string="Product variant",
        help=("When this field is filled in, the vendor data will only"
              "apply to the variant."))

    @api.onchange('name')
    def _onchange_name_discount(self):
        disc = 0.0
        price = 0.0
        if self.name:
            disc = self.name.supplier_discount
            if self.product_id:
                price = (self.product_id.lst_price - (self.product_id.lst_price * disc)/100)
            else:
                price = (self.product_tmpl_id.lst_price - (self.product_tmpl_id.lst_price * disc)/100)
            self.update({
                'purchase_discount': disc,
                'price': price
            })

    @api.onchange('purchase_discount')
    def _onchange_purchase_discount(self):
        disc = 0.0
        price = 0.0
        if self.purchase_discount:
            disc = self.purchase_discount
            if self.product_id:
                price = (self.product_id.lst_price - (self.product_id.lst_price * disc)/100)
            else:
                price = (self.product_tmpl_id.lst_price - (self.product_tmpl_id.lst_price * disc)/100)
            self.update({
                'price': price
            })

    def _check_product_template(self, vals):
        # Make a copy in case original dictionary is preferred to be kept
        vals = vals.copy()
        if vals.get('product_id'):
            product = self.env['product.product'].browse(vals['product_id'])
            vals['product_tmpl_id'] = product.product_tmpl_id.id
        return vals

    @api.model
    def create(self, vals):
        vals = self._check_product_template(vals)
        return super(ProductSupplierInfo, self).create(vals)

    @api.multi
    def write(self, vals):
        vals = self._check_product_template(vals)
        return super(ProductSupplierInfo, self).write(vals)


class SaleOrderLine(models.Model):
    _inherit = "sale.order.line"

    # name = fields.Text(string='Description', required=False)
    another_cost = fields.Float(string='Cost', compute='_cost_calculation')

    @api.depends('product_id.variant_seller_ids.purchase_discount', 'product_id.seller_ids.purchase_discount')
    def _cost_calculation(self):
        des = 0.0
        rec = 0.0
        for record in self:
            if record.product_id.variant_seller_ids:
                des = record.product_id.variant_seller_ids[0].purchase_discount
                rec = (record.product_id.lst_price*des)/100
                record.another_cost = record.product_id.lst_price - rec
            elif record.product_id.seller_ids:
                des = record.product_id.seller_ids[0].purchase_discount
                rec = (record.product_id.lst_price*des)/100
                record.another_cost = record.product_id.lst_price - rec
            else:
                return

    def _get_sale_order_line_multiline_description_variants(self):
        """When using no_variant attributes or is_custom values, the product
        itself is not sufficient to create the description: we need to add
        information about those special attributes and values.

        See note about `product_no_variant_attribute_value_ids` above the field
        definition: this method is not reliable to recompute the description at
        a later time, it should only be used initially.

        :return: the description related to special variant attributes/values
        :rtype: string
        """
        if not self.product_custom_attribute_value_ids and not self.product_no_variant_attribute_value_ids:
            return ""

        name = "\n"

        product_attribute_with_is_custom = self.product_custom_attribute_value_ids.mapped('attribute_value_id.attribute_id')

        # display the no_variant attributes, except those that are also
        # displayed by a custom (avoid duplicate)
        for no_variant_attribute_value in self.product_no_variant_attribute_value_ids.filtered(
            lambda ptav: ptav.attribute_id not in product_attribute_with_is_custom
        ):
            name += "\n" + no_variant_attribute_value.attribute_id.name + ': ' + no_variant_attribute_value.name

        # display the is_custom values
        for pacv in self.product_custom_attribute_value_ids:
            name += "\n" + pacv.attribute_value_id.attribute_id.name + \
                ': ' + pacv.attribute_value_id.name + \
                ': ' + (pacv.custom_value or '').strip()

        return name

    def get_sale_order_line_multiline_description_sale(self, product):
        """ Compute a default multiline description for this sales order line.
        This method exists so it can be overridden in other modules to change how the default name is computed.
        In general only the product is used to compute the name, and this method would not be necessary (we could directly override the method in product).
        BUT in event_sale we need to know specifically the sales order line as well as the product to generate the name:
            the product is not sufficient because we also need to know the event_id and the event_ticket_id (both which belong to the sale order line).
        """
        # product_width = product.width
        # product_height = product.height
        # product_seating_width = product.seating_height
        return product.get_product_multiline_description_sale() + self._get_sale_order_line_multiline_description_variants()

    @api.multi
    @api.onchange('product_id')
    def product_id_change(self):
        if not self.product_id:
            return {'domain': {'product_uom': []}}

        # remove the is_custom values that don't belong to this template
        for pacv in self.product_custom_attribute_value_ids:
            if pacv.attribute_value_id not in self.product_id.product_tmpl_id._get_valid_product_attribute_values():
                self.product_custom_attribute_value_ids -= pacv

        # remove the no_variant attributes that don't belong to this template
        for ptav in self.product_no_variant_attribute_value_ids:
            if ptav.product_attribute_value_id not in self.product_id.product_tmpl_id._get_valid_product_attribute_values():
                self.product_no_variant_attribute_value_ids -= ptav

        vals = {}
        domain = {'product_uom': [('category_id', '=', self.product_id.uom_id.category_id.id)]}
        if not self.product_uom or (self.product_id.uom_id.id != self.product_uom.id):
            vals['product_uom'] = self.product_id.uom_id
            vals['product_uom_qty'] = self.product_uom_qty or 1.0

        product = self.product_id.with_context(
            lang=self.order_id.partner_id.lang,
            partner=self.order_id.partner_id,
            quantity=vals.get('product_uom_qty') or self.product_uom_qty,
            date=self.order_id.date_order,
            pricelist=self.order_id.pricelist_id.id,
            uom=self.product_uom.id
        )

        result = {'domain': domain}

        # name = product.product_tmpl_id.name
        name = self.get_sale_order_line_multiline_description_sale(product)

        vals.update(name=name)

        self._compute_tax_id()

        if self.order_id.pricelist_id and self.order_id.partner_id:
            vals['price_unit'] = self.env['account.tax']._fix_tax_included_price_company(self._get_display_price(product), product.taxes_id, self.tax_id, self.company_id)
        self.update(vals)

        title = False
        message = False
        warning = {}
        if product.sale_line_warn != 'no-message':
            title = _("Warning for %s") % product.name
            message = product.sale_line_warn_msg
            warning['title'] = title
            warning['message'] = message
            result = {'warning': warning}
            if product.sale_line_warn == 'block':
                self.product_id = False

        return result


class SaleOrder(models.Model):
    _inherit = "sale.order"

    show_discount = fields.Boolean(default=True)
    another_cost = fields.Float(string='Cost', related='order_line.another_cost')


class ResPartner(models.Model):
    _inherit = "res.partner"

    supplier_discount = fields.Float(string='Supplier Discount')


class AccountInvoice(models.Model):
    _inherit = "account.invoice"

    deli_date = fields.Date(string='Delivery Date')


class ProductAttribute(models.Model):
    _inherit = "product.attribute"

    custom_attr_name = fields.Char(string='Custom Attribute Name', required=True)
    attr_value = fields.Boolean(string='Print On Quotation', default=True)


class PurchaseOrder(models.Model):
    _inherit = "purchase.order"

    extra_discount = fields.Float(string='Extra Discount')
    after_discount = fields.Float(string='After Discount', readonly=True)

    @api.depends('amount_total')
    def purchase_order_calculation(self):
        if self.extra_discount:
            doc = (self.amount_total*self.extra_discount)/100
            self.after_discount = self.amount_total - doc


class ProductTemplate(models.Model):
    _inherit = "product.template"

    standard_price = fields.Float(compute='_purchase_calculation')
    res = fields.Float('Purchase Discount', related='variant_seller_ids.purchase_discount')
    length = fields.Char(string="Length")
    width = fields.Char(string="Width")
    height = fields.Char(string="Height")
    seating_height = fields.Char(string="Seating Height")

    @api.depends('list_price', 'res')
    def _purchase_calculation(self):
        for record in self:
            rec = record.variant_seller_ids[0].purchase_discount if record.variant_seller_ids else False
            if rec:
                doc = (record.list_price*rec)/100
                record.standard_price = record.list_price - doc

    @api.onchange('list_price')
    def _onchange_list_price(self):
        for res in self.variant_seller_ids:
            res.price = ((self.list_price + res.product_id.price_extra) - ((self.list_price + res.product_id.price_extra) * res.purchase_discount)/100)
        return


class AccountInvo(models.Model):
    _inherit = 'account.invoice'

    def show_disc(self):
        for rec in self.invoice_line_ids:
            if rec.discount:
                return rec.discount


class StockMove(models.Model):
    _inherit = 'stock.move'

    description = fields.Text('Description')

    def get_move_name(self):
        product = self.product_id
        name = product.name
        if product.length and product.width:
            name += '\n' + 'Dim.: '
            name += product.length + 'x'
            name += product.width + 'x'
        if product.seating_height:
            name += product.seating_height
        if product.height:
            if product.seating_height:
                name += '/'
        if product.height:
            name += product.height
        if product.seating_height:
            name += ' cm/h'
        if product.description_sale:
            name += '\n' + product.description_sale
        return name

    @api.model
    def create(self, vals):
        res = super(StockMove, self).create(vals)
        res.description = res.get_move_name()
        return res


class ProductProduct(models.Model):
    _inherit = 'product.product'

    seller_ids = fields.Many2many(
        'product.supplierinfo',
        compute='_compute_seller_ids')
    seller_delay = fields.Integer(
        related='seller_ids.delay',
        string='Supplier Lead Time',
        help=("This is the average delay in days between the purchase order "
              "confirmation and the receipts for this product and for the "
              "default supplier. It is used by the scheduler to order "
              "requests based on reordering delays."))
    seller_qty = fields.Float(
        related='seller_ids.min_qty',
        string='Supplier Min Quantity',
        help="This is minimum quantity to purchase from Main Supplier.")
    seller_id = fields.Many2one(
        related='seller_ids.name',
        relation='res.partner',
        string='Main Supplier',
        help="Main Supplier who has highest priority in Supplier List.")
    variant_seller_ids = fields.One2many(
        'product.supplierinfo',
        'product_id')
    tmpl_seller_ids = fields.Many2many(
        'product.supplierinfo',
        compute='_compute_seller_ids')

    @api.multi
    def _compute_seller_ids(self):
        for product in self:
            sellers = product.product_tmpl_id.seller_ids
            product.tmpl_seller_ids = sellers.filtered(
                lambda x: not x.product_id)
            product.seller_ids = sellers.filtered(
                lambda x: not x.product_id or x.product_id == product)
