# -*- encoding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2012-TODAY Acespritech Solutions Pvt Ltd
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################


from odoo import api, fields, models, _


class sale_order_line(models.Model):
    _inherit = 'sale.order.line'

    show_discount = fields.Boolean('Show Discount')
    position = fields.Char('Position')

    @api.multi
    def cal_price_uint(self):
        for line in self:
            if not line.show_discount and line.discount:
                price_uint = "%.2f" %(line.price_unit - (line.price_unit * (line.discount/100)))
            elif not line.show_discount and not line.discount:
                price_uint = "%.2f" %(line.price_unit)
        return price_uint


    @api.multi
    def _prepare_invoice_line(self, qty):
        """
        Prepare the dict of values to create the new invoice line for a sales order line.

        :param qty: float quantity to invoice
        """
        self.ensure_one()
        res = {}
        account = self.product_id.property_account_income_id or self.product_id.categ_id.property_account_income_categ_id

        if not account and self.product_id:
            raise UserError(_('Please define income account for this product: "%s" (id:%d) - or for its category: "%s".') %
                (self.product_id.name, self.product_id.id, self.product_id.categ_id.name))

        fpos = self.order_id.fiscal_position_id or self.order_id.partner_id.property_account_position_id
        if fpos and account:
            account = fpos.map_account(account)

        res = {
            'name': self.name,
            'sequence': self.sequence,
            'origin': self.order_id.name,
            'account_id': account.id,
            'price_unit': self.price_unit,
            'quantity': qty,
            'discount': self.discount,
            'uom_id': self.product_uom.id,
            'product_id': self.product_id.id or False,
            'invoice_line_tax_ids': [(6, 0, self.tax_id.ids)],
            'account_analytic_id': self.order_id.analytic_account_id.id,
            'analytic_tag_ids': [(6, 0, self.analytic_tag_ids.ids)],
            'display_type': self.display_type,
        }
        res.update({
            'position': self.position or False,
            })
        return res


    # @api.multi
    # @api.onchange('product_id')
    # def product_id_change(self):
    #     res = super(sale_order_line, self).product_id_change()
    #     vals = {}
    #     product = self.product_id.with_context(
    #         lang=self.order_id.partner_id.lang,
    #         partner=self.order_id.partner_id,
    #         quantity=vals.get('product_uom_qty') or self.product_uom_qty,
    #         date=self.order_id.date_order,
    #         pricelist=self.order_id.pricelist_id.id,
    #         uom=self.product_uom.id
    #     )
        
    #     name = product.name
    #     if product.description_sale:
    #         name += '\n' + product.description_sale
    #     vals['name'] = name
    #     self.update(vals)
    #     return res


class sale_order(models.Model):
    _inherit = "sale.order"

    def _get_subject(self):
        if self._uid:
            user_id = self.env['res.users'].browse([self._uid])
            if user_id and user_id.company_id and user_id.company_id.subject:
                return user_id.company_id.subject

    def _get_order_subject(self):
        if self._uid:
            user_id = self.env['res.users'].browse([self._uid])
            if user_id and user_id.company_id and user_id.company_id.subject_for_order:
                return user_id.company_id.subject_for_order

    def _get_order_cover_quot(self):
        if self._uid:
            user_id = self.env['res.users'].browse([self._uid])
            if user_id and user_id.company_id and user_id.company_id.cover_note_quot:
                return user_id.company_id.cover_note_quot

    def _get_order_cover_sale(self):
        if self._uid:
            user_id = self.env['res.users'].browse([self._uid])
            if user_id and user_id.company_id and user_id.company_id.cover_note_sale:
                return user_id.company_id.cover_note_sale

    def _get_order_delivery_term1(self):
        if self._uid:
            user_id = self.env['res.users'].browse([self._uid])
            if user_id and user_id.company_id and user_id.company_id.term1:
                return user_id.company_id.term1

    def _get_order_delivery_weeks(self):
        if self._uid:
            user_id = self.env['res.users'].browse([self._uid])
            if user_id and user_id.company_id and user_id.company_id.expected_delivery_term:
                return user_id.company_id.expected_delivery_term



    sale_subject = fields.Text('Subject For Quotation', default=_get_subject)
    sale_order_subject = fields.Text('Subject For Order', default=_get_order_subject)
    cover_note_quot = fields.Text('Cover Note Quote', default=_get_order_cover_quot)
    cover_note_sale = fields.Text('Cover Note Sale', default=_get_order_cover_sale)
    delivery_term1 = fields.Text('Delivery Terms', default=_get_order_delivery_term1) 
    delivery_weeks = fields.Char('Delivery Weeks', default=_get_order_delivery_weeks)


    def show_discount_head(self):
        for line in self.order_line:
            if line.show_discount is True:
                return True
        return False

    def show_tax(self):
        taxes = []
        for line in self.order_line:
            if line.tax_id:
                if line.tax_id.description not in taxes:
                    taxes.append(line.tax_id.description)
                # # return line.tax_id.name + ' ' + str(int(line.tax_id.amount)) + '%'
                # # return line.tax_id.name + ' ' + str(int(line.tax_id.amount))
                # if tax_count == 0:
                #     taxes += " " + str(c)
                #     tax_count += 1
                # else:
                #     taxes += " + " + str(line.tax_id.description)
        return taxes

    # def show_tax(self):
    #     taxes = ""
    #     tax_count = 0
    #     for line in self.order_line:
    #         if line.tax_id:
    #             # return line.tax_id.name + ' ' + str(int(line.tax_id.amount)) + '%'
    #             # return line.tax_id.name + ' ' + str(int(line.tax_id.amount))
    #             if tax_count == 0:
    #                 taxes += " " + str(line.tax_id.description)
    #                 tax_count += 1
    #             else:
    #                 taxes += " + " + str(line.tax_id.description)
    #     return taxes

    def show_discount(self, line, context=None):
        if line.show_discount:
            return True
        return False

class Picking(models.Model):
    _inherit = "stock.picking"

    def get_order_data(self):
        vals = {}
        if self.origin:
            sale_id = self.env['sale.order'].search([('name','=',self.origin)])
            if sale_id:
                vals = {
                   'user_id':sale_id.user_id.name,
                   'phone':sale_id.user_id.phone,
                   'email':sale_id.user_id.email,
                       }
        return vals


    def get_product_position(self, product):
        vals = {}
        if self.origin:
            sale_id = self.env['sale.order'].search([('name','=',self.origin)]) 
            if sale_id:
                order_line_id = self.env['sale.order.line'].search([('order_id', '=', sale_id.id), ('product_id', '=', product)])
                for order_line in order_line_id:
                    for move_line in self.move_lines:
                        if order_line.product_id.id == move_line.product_id.id:
                            if order_line.product_uom_qty == move_line.product_uom_qty:
                                vals = {
                                   'position': order_line.position,
                                   'product_name': order_line.product_id.name,
                                   'length': order_line.product_id.length,
                                   'width': order_line.product_id.width,
                                   'height': order_line.product_id.height,
                                   'seating_height': order_line.product_id.seating_height,
                                   'product_attrs': order_line.product_id.attrs_value,
                                       }
                                print('>>>>>>>>>>>>>>>>>>>>>>>>', vals)
        return vals


class account_invoice_line(models.Model):
    _inherit = 'account.invoice.line'

    position = fields.Char('Position')

    @api.onchange('product_id')
    def onchange_product_id(self):
        domain = {}
        if not self.invoice_id:
            return
        part = self.invoice_id.partner_id
        if self.product_id:
            if part.lang:
                product = self.product_id.with_context(lang=part.lang)
            else:
                product = self.product_id
            self.name = product.name
            if self.invoice_id.type in ('in_invoice', 'in_refund'):
                if product.description_purchase:
                    self.name += '\n' + product.description_purchase
            else:
                if product.description_sale:
                    self.name += '\n' + product.description_sale
            domain['uom_id'] = [('category_id', '=', product.uom_id.category_id.id)]
        else: 
            domain['uom_id'] = []
        return {'domain': domain}


class CustomAccountInvoice(models.Model):
    _inherit = 'account.invoice'

    def show_tax_invoice(self):
        invoice_taxes = []
        for l in self.invoice_line_ids:
            if l.invoice_line_tax_ids:
                if l.invoice_line_tax_ids.description not in invoice_taxes:
                    invoice_taxes.append(l.invoice_line_tax_ids.description)
                # # return line.tax_id.name + ' ' + str(int(line.tax_id.amount)) + '%'
                # # return line.tax_id.name + ' ' + str(int(line.tax_id.amount))
                # if tax_count == 0:
                #     taxes += " " + str(c)
                #     tax_count += 1
                # else:
                #     taxes += " + " + str(line.tax_id.description)
        return invoice_taxes

    # def show_tax(self):
    #     taxes = ""
    #     tax_count = 0
    #     for line in self.invoice_line_ids:
    #         if line.invoice_line_tax_ids:
    #             # return line.invoice_line_tax_ids.name + ' ' + str(int(line.invoice_line_tax_ids.amount)) + '%'
    #             # return line.invoice_line_tax_ids.description
    #             if tax_count == 0:
    #                 taxes += " " + str(line.invoice_line_tax_ids.description)
    #                 tax_count += 1
    #             else:
    #                 taxes += " + " + str(line.invoice_line_tax_ids.description)
    #     return taxes


class purchase_order_line(models.Model):
    _inherit = 'purchase.order.line'

    position = fields.Char('Position')

    @api.onchange('product_id')
    def onchange_product_id(self):
        res = super(purchase_order_line, self).onchange_product_id()
        product_lang = self.product_id.with_context(
            lang=self.partner_id.lang,
            partner_id=self.partner_id.id,
        )
        self.name = product_lang.name
        if product_lang.description_purchase:
            self.name += '\n' + product_lang.description_purchase
        if product_lang.standard_price:
            self.price_unit = product_lang.standard_price
        else:
            self.price_unit = product_lang.lst_price
        return res


class CustomPurchaseOrder(models.Model):
    _inherit = 'purchase.order'

    use_other_delivery_address = fields.Boolean(string="Other Delivery Address", 
         help="Check if deliviers from Vendor go directly to client or other address.")
    other_delivery_address = fields.Text(string="Delivery Address")

    @api.multi
    def write(self, values):
        res = super(CustomPurchaseOrder, self).write(values)
        if 'use_other_delivery_address' in values:
            if values['use_other_delivery_address'] == False:
                self.other_delivery_address = False
        return res