# -*- encoding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2012-TODAY Acespritech Solutions Pvt Ltd
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from odoo import api, fields, models, _


class res_company(models.Model):
    _inherit = 'res.company'

    report_image = fields.Binary(string="Report Logo")
    subject = fields.Text("Sale Default Subject For Quotation")
    subject_for_order = fields.Text("Default Subject For Order")
    term1 = fields.Text('Delivery Term 1')
    term2 = fields.Text('Delivery Term 2')
    acc_term = fields.Text('Account Terms And Condition')
    expected_delivery_term = fields.Text('Expected Delivery Weeks')
    cover_note_quot = fields.Text('Cover Note Quot')
    cover_note_sale = fields.Text('Cover Note Sale') 

