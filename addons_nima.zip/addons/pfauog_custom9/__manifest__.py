# -*- coding: utf-8 -*-
##############################################################################
#    OpenERP, Open Source Management Solution
#    Copyright (c) 2013-Present Acespritech Solutions Pvt. Ltd. (<http://acespritech.com>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

{
    "name": "pfauog_custom9",
    "version": "0.1",
    "description": 
    """
        Odoo changes for pfauog.""",
    "author": "Acespritech Solutions Pvt.Ltd",
    "website": "http://www.acespritech.com",
    "depends": ["base", 'sale_management', 'product_margin', 'sale_margin', 'purchase', 'stock', 'account', 'global_discount9'],
    "category": "Custom Modules",
    "data": [
        'report/sale_report.xml',
        'report/sale_report_templates.xml',
        # 'report/report_invoice.xml',
        'report/report_deliveryslip.xml',
        'report/purchase_order_templates.xml',
        'views/res_company_view.xml',
        'views/res_partner_view.xml',
        'views/sale_view.xml',
    ],
#     "installable": True
    "images":['img/footer.png']
}
