# -*- encoding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (c) 2013-Present Acespritech Solutions Pvt. Ltd.
#     (<http://acespritech.com>).
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as published
#    by the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

{
    'name': "Global Discount",
    'version': '1.1',
    'category': 'Account',
    'description': """Add a global discount in sale order \
                                    and account invoice""",
    'author': 'Acespritech Solutions Pvt.Ltd',
    'website': 'http://www.acespritech.com',
    "depends": ['base', 'sale', 'account', 'stock'],
    "init_xml": [],
    "data": [
        'views/account_invoice_view.xml',
        'views/sale_view.xml',
        'views/res_company_view.xml',
        ],
    "installable": True,
#     "images": ['images/image.png'],
}
