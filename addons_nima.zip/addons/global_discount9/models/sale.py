# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2004-2010 Tiny SPRL (<http://tiny.be>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
from odoo import api, exceptions, fields, models, _
from odoo.exceptions import AccessError, UserError, RedirectWarning, ValidationError, Warning

class sale_order(models.Model):
    _inherit = "sale.order"


    @api.depends('order_line.price_total','order_line.tax_id', 'discount_amt','disc_selection')
    def _amount_all(self):
        """
        Compute the total amounts of the SO.
        """
        for order in self:
            amount_untaxed = amount_tax = 0.0
            applied_disc = 0
            for line in order.order_line:
                amount_untaxed += line.price_subtotal
                amount_tax += line.price_tax
                if order.discount_amt < 0:
                    raise UserError(_('No negative amount!'),
                                    _("You must enter a positive amount for discount"))
                if (order.disc_selection == 'percentage'):
                    applied_disc = amount_untaxed * (order.discount_amt) / 100
            order.update({
                'amount_untaxed': order.pricelist_id.currency_id.round(amount_untaxed),
                'amount_tax': order.pricelist_id.currency_id.round(amount_tax),
                'amount_total': amount_untaxed + amount_tax - applied_disc,
                'applied_disc': applied_disc,
                'after_discount': amount_untaxed - applied_disc,
                'amount_no_discount': amount_untaxed + amount_tax,
                'appl_disc': amount_untaxed - applied_disc
            })

    expected_delivery = fields.Char('Expected Delivery Time', size=256)
    discount_amt = fields.Integer('Discount In %', default=0)
    disc_selection = fields.Selection([('percentage', 'Pecentage'), ('fixed', 'Fixed')],
                                      string= 'Discount In %', default="percentage")
    applied_disc = fields.Monetary('Applied Discount', compute="_amount_all", store=True)
    amount_no_discount = fields.Monetary('Total Without Discount', compute="_amount_all", store=True)
    after_discount = fields.Monetary('After Global Discount', compute="_amount_all", store=True)
    appl_disc = fields.Float(string='Applied Discount', compute='_amount_all')

    @api.multi
    def _prepare_invoice(self):
        """
        Prepare the dict of values to create the new invoice for a sales order. This method may be
        overridden to implement custom invoice generation (making sure to call super() to establish
        a clean extension chain).
        """
        self.ensure_one()
        journal_id = self.env['account.invoice'].default_get(['journal_id'])['journal_id']
        if not journal_id:
            raise UserError(_('Please define an accounting sale journal for this company.'))
        invoice_vals = {
            'name': self.client_order_ref or '',
            'origin': self.name,
            'type': 'out_invoice',
            # 'reference': self.client_order_ref or self.name,
            'account_id': self.partner_invoice_id.property_account_receivable_id.id,
            'partner_id': self.partner_invoice_id.id,
            'journal_id': journal_id,
            'currency_id': self.pricelist_id.currency_id.id,
            'comment': self.note,
            'payment_term_id': self.payment_term_id.id,
            'fiscal_position_id': self.fiscal_position_id.id or self.partner_invoice_id.property_account_position_id.id,
            'company_id': self.company_id.id,
            'user_id': self.user_id and self.user_id.id,
            'team_id': self.team_id.id,
            'transaction_ids': [(6, 0, self.transaction_ids.ids)],
            'discount_type': self.disc_selection,
            'discount_amt': self.discount_amt,
            'applied_disc': self.applied_disc,
            'another_cost': self.another_cost,
        }
        return invoice_vals

    @api.multi
    def button_dummy(self):
        for order in self:
            for line in order.order_line:
                if order.applied_disc:
                    order.amount_tax = order.after_discount * (line.tax_id.amount) / 100
                if order.after_discount:
                    order.amount_total = order.after_discount + order.amount_tax
        return True

class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'

    @api.depends('product_uom_qty', 'discount', 'price_unit', 'tax_id', 'order_id.discount_amt')
    def _compute_amount(self):
        """
        Compute the amounts of the SO line.
        """
        for line in self:
            if line.order_id.discount_amt > 0:
                price = line.price_unit * (1 - (line.discount or 0.0) / 100.0)
                taxes = line.tax_id.compute_all(price, line.order_id.currency_id, line.product_uom_qty, product=line.product_id, partner=line.order_id.partner_id)
                price1 = (line.price_unit * (1 - (line.discount or 0.0) / 100.0)) * (1 - (line.order_id.discount_amt or 0.0) / 100.0)
                taxes1 = line.tax_id.compute_all(
                    price1, line.order_id.currency_id, line.product_uom_qty, product=line.product_id, partner=line.order_id.partner_id)
                line.update({
                    'price_tax': sum(t.get('amount', 0.0) for t in taxes.get('taxes', [])),
                    'price_total': taxes['total_included'],
                    'price_subtotal': taxes['total_excluded'],
                    'total_with_global_disc': taxes1['total_excluded']
                })
            else:
                price = line.price_unit * (1 - (line.discount or 0.0) / 100.0)
                taxes = line.tax_id.compute_all(price, line.order_id.currency_id, line.product_uom_qty, product=line.product_id, partner=line.order_id.partner_id)
                line.update({
                    'price_tax': sum(t.get('amount', 0.0) for t in taxes.get('taxes', [])),
                    'price_total': taxes['total_included'],
                    'price_subtotal': taxes['total_excluded'],
                    'total_with_global_disc': taxes['total_excluded']
                })

    total_with_global_disc = fields.Float('Total With Global Disc', compute="_compute_amount", store=True)

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
