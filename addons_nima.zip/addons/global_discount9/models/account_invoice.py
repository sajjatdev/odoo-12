# -*- encoding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (c) 2013-Present Acespritech Solutions Pvt. Ltd.
#     (<http://acespritech.com>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as published
#    by the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from odoo import api, exceptions, fields, models, _
from odoo.exceptions import AccessError, UserError, RedirectWarning, ValidationError, Warning
from odoo.addons import decimal_precision as dp
from odoo.tools import float_is_zero, float_compare

class account_invoice(models.Model):
    _inherit = "account.invoice"

    @api.one
    @api.depends('discount_type', 'discount_amt')
    def compute_discount(self):
        for order in self:
            for line in order.invoice_line_ids:
                if order.applied_disc:
                    order.amount_tax = order.after_discount * (line.invoice_line_tax_ids.amount) / 100
                if order.after_discount:
                    order.amount_total = order.after_discount + order.amount_tax
        if self.discount_amt != 0 and self.discount_type is False:
            raise Warning(_('No Discount Type Selected!'),
                          _("You must select any one of discount type."))
        self._compute_amount()
        return True

    @api.one
    @api.depends('invoice_line_ids.price_subtotal', 'tax_line_ids.amount', 'tax_line_ids.amount_rounding', 
                 'currency_id', 'company_id', 'date_invoice', 'type', 'discount_amt')
    def _compute_amount(self):
        round_curr = self.currency_id.round
        self.amount_untaxed = sum(line.price_subtotal for line in self.invoice_line_ids)
        self.amount_tax = sum(round_curr(line.amount_total) for line in self.tax_line_ids)
#         self.amount_total = self.amount_untaxed + self.amount_tax
        discount = self.discount_amt or 0
        if self.discount_type == 'percentage':
            discount = (self.amount_untaxed * self.discount_amt) / 100
        amount_total_company_signed = self.amount_total
        amount_untaxed_signed = self.amount_untaxed
        # if self.currency_id and self.currency_id != self.company_id.currency_id:
        if self.currency_id and self.company_id and self.currency_id != self.company_id.currency_id:
            currency_id = self.currency_id
            # amount_total_company_signed = currency_id.compute(self.amount_total, self.company_id.currency_id)
            amount_total_company_signed = currency_id._convert(self.amount_total, self.company_id.currency_id, self.company_id, self.date_invoice or fields.Date.today())
            # amount_untaxed_signed = currency_id.compute(self.amount_untaxed, self.company_id.currency_id)
            amount_untaxed_signed = currency_id._convert(self.amount_untaxed, self.company_id.currency_id, self.company_id, self.date_invoice or fields.Date.today())
            # amount_total_company_signed = self.currency_id.compute(self.amount_total, self.company_id.currency_id)
            # amount_untaxed_signed = self.currency_id.compute(self.amount_untaxed, self.company_id.currency_id)
        sign = self.type in ['in_refund', 'out_refund'] and -1 or 1
        self.amount_total_company_signed = amount_total_company_signed * sign
        self.amount_total_signed = self.amount_total * sign
        self.amount_untaxed_signed = amount_untaxed_signed * sign
        self.applied_disc = discount
        self.amount_total = self.amount_untaxed - discount + self.amount_tax
        self.amt_total = self.amount_untaxed + self.amount_tax
        self.after_discount = self.amount_untaxed - self.applied_disc


    discount_type = fields.Selection([
        ('percentage', 'Percentage'), 
        ('fixed', 'Fixed')
        ], 'Discount Type', default="percentage")
    discount_amt = fields.Integer(string="Discount In %")
    amt_total = fields.Monetary(compute='_compute_amount', string="Total without Discount", store=True)
    applied_disc = fields.Monetary(compute='_compute_amount', string="Applied Discount", store=True)
    after_discount = fields.Monetary('After Global Discount', store=True, readonly=True)

    @api.multi
    def get_taxes_values(self):
        tax_grouped = {}
        for line in self.invoice_line_ids:
            if not line.account_id:
                continue
            price_unit = line.price_unit * (1 - (line.discount or 0.0) / 100.0)
            price_unit1 = (line.price_unit * (1 - (line.discount or 0.0) / 100.0)) * (1 - (self.discount_amt or 0.0) / 100.0)
            taxes = line.invoice_line_tax_ids.compute_all(price_unit, self.currency_id, line.quantity, line.product_id, self.partner_id)['taxes']
            taxes1 = line.invoice_line_tax_ids.compute_all(price_unit1, self.currency_id, line.quantity, line.product_id, self.partner_id)['taxes']
            val = {}
            tax = {}
            if self.discount_amt > 0:
                for tax in taxes1:
                    val = {
                        'invoice_id': self.id,
                        'name': tax['name'],
                        'tax_id': tax['id'],
                        'amount': tax['amount'],
                        'manual': False,
                        'sequence': tax['sequence'],
                        'account_analytic_id': tax['analytic'] and line.account_analytic_id.id or False,
                        'account_id': self.type in ('out_invoice', 'in_invoice') and (tax['account_id'] or line.account_id.id) or (tax['refund_account_id'] or line.account_id.id),
                    }
            else:
                for tax in taxes:
                    val = {
                        'invoice_id': self.id,
                        'name': tax['name'],
                        'tax_id': tax['id'],
                        'amount': tax['amount'],
                        'manual': False,
                        'sequence': tax['sequence'],
                        'account_analytic_id': tax['analytic'] and line.account_analytic_id.id or False,
                        'account_id': self.type in ('out_invoice', 'in_invoice') and (tax['account_id'] or line.account_id.id) or (tax['refund_account_id'] or line.account_id.id),
                    }

                # If the taxes generate moves on the same financial account as the invoice line,
                # propagate the analytic account from the invoice line to the tax line.
                # This is necessary in situations were (part of) the taxes cannot be reclaimed,
                # to ensure the tax move is allocated to the proper analytic account.
            if not val.get('account_analytic_id') and line.account_analytic_id and val['account_id'] == line.account_id.id:
                val['account_analytic_id'] = line.account_analytic_id.id


            if tax.get('id'):    
                key = tax['id']
                if key not in tax_grouped:
                    tax_grouped[key] = val
                else:
                    tax_grouped[key]['amount'] += val['amount']
                    # tax_grouped[key]['base'] += val['base']
        return tax_grouped

    @api.multi
    @api.returns('self')
    def refund(self, date_invoice=None, date=None, description=None, journal_id=None):
        new_invoices = self.browse()
        for invoice in self:
            # create the new invoice
            values = self._prepare_refund(invoice, date_invoice=date_invoice, date=date,
                                    description=description, journal_id=journal_id)
            refund_invoice = self.create(values)
            if invoice.applied_disc and values.get('invoice_line'):
                values['invoice_line'].append((0, 0,
                                               {'account_id': disc_account,
                                                'name': u'Discount Refunded',
                                                'price_unit': -invoice.applied_disc,
                                                'quantity': 1,
                                                }),
                                              )
            if invoice.type == 'out_invoice':
                message = _("This customer invoice credit note has been created from: <a href=# data-oe-model=account.invoice data-oe-id=%d>%s</a><br>Reason: %s") % (invoice.id, invoice.number, description)
            else:
                message = _("This vendor bill credit note has been created from: <a href=# data-oe-model=account.invoice data-oe-id=%d>%s</a><br>Reason: %s") % (invoice.id, invoice.number, description)

            refund_invoice.message_post(body=message)
            new_invoices += refund_invoice
        return new_invoices

    @api.one
    @api.depends(
        'state', 'currency_id', 'invoice_line_ids.price_subtotal',
        'move_id.line_ids.amount_residual',
        'move_id.line_ids.currency_id')
    def _compute_residual(self):
        residual = 0.0
        residual_company_signed = 0.0
        move_line_count = 0
        sign = self.type in ['in_refund', 'out_refund'] and -1 or 1
        for line in self.sudo().move_id.line_ids:
            if line.account_id == self.account_id:
                residual_company_signed += line.amount_residual
                if line.currency_id == self.currency_id:
                    residual += line.amount_residual_currency if line.currency_id else line.amount_residual
                else:
                    from_currency = line.currency_id or line.company_id.currency_id
                    residual += from_currency._convert(line.amount_residual, self.currency_id, line.company_id, line.date or fields.Date.today())
                move_line_count += 1
        if move_line_count != 0:
            self.residual_company_signed = abs(residual_company_signed - self.applied_disc) * sign
            self.residual_signed = abs(residual - self.applied_disc) * sign
            self.residual = abs(residual - self.applied_disc)
        else:
            self.residual_company_signed = abs(residual_company_signed) * sign
            self.residual_signed = abs(residual) * sign
            self.residual = abs(residual)
        digits_rounding_precision = self.currency_id.rounding
        if float_is_zero(self.residual, precision_rounding=digits_rounding_precision):
            self.reconciled = True
        else:
            self.reconciled = False

    @api.multi
    def compute_invoice_totals(self, company_currency, invoice_move_lines):
        total = 0
        total_currency = 0
        for line in invoice_move_lines:
            if self.currency_id != company_currency:
                # currency = self.currency_id.with_context(date=self._get_currency_rate_date() or fields.Date.context_today(self))
                currency = self.currency_id
                date = self._get_currency_rate_date() or fields.Date.context_today(self)
                if not (line.get('currency_id') and line.get('amount_currency')):
                    line['currency_id'] = currency.id
                    line['amount_currency'] = currency.round(line['price'])
                    # line['price'] = currency.compute(line['price'], company_currency)
                    line['price'] = currency._convert(line['price'], company_currency, self.company_id, date)
            else:
                line['currency_id'] = False
                line['amount_currency'] = False
                line['price'] = self.currency_id.round(line['price'])
            if self.type in ('out_invoice', 'in_refund'):
                total += line['price']
                total_currency += line['amount_currency'] or line['price']
                line['price'] = - line['price']
            else:
                total -= line['price']
                total_currency -= line['amount_currency'] or line['price']
        # total -= self.applied_disc
        if self.currency_id != company_currency:
            currency = self.currency_id
            date = self._get_currency_rate_date() or fields.Date.context_today(self)
            applied_disc = currency._convert(self.applied_disc, company_currency, self.company_id, date)
            total = currency.round(total - applied_disc)
            total_currency = currency.round(total_currency - applied_disc)
        else:
            discount_amt = self.currency_id.round(self.applied_disc)
            total -= discount_amt
            total_currency -= discount_amt
        return total, total_currency, invoice_move_lines


    @api.multi
    def action_move_create(self):
        """ Creates invoice related analytics and financial move lines 
        override this function to add a move line for discount amount to balance the invoice total in journal"""
        account_move = self.env['account.move']
        for inv in self:
            if not inv.journal_id.sequence_id:
                raise UserError(_('Please define sequence on the journal related to this invoice.'))
            if not inv.invoice_line_ids.filtered(lambda line: line.account_id):
                raise UserError(_('Please add at least one invoice line.'))
            if inv.move_id:
                continue

            # ctx = dict(self._context, lang=inv.partner_id.lang)

            if not inv.date_invoice:
                inv.write({'date_invoice': fields.Date.context_today(self)})
            if not inv.date_due:
                inv.write({'date_due': inv.date_invoice})
            date_invoice = inv.date_invoice
            company_currency = inv.company_id.currency_id

            # create move lines (one per invoice line + eventual taxes and analytic lines)
            iml = inv.invoice_line_move_line_get()
            iml += inv.tax_line_move_line_get()

            diff_currency = inv.currency_id != company_currency
            # create one move line for the total and possibly adjust the other lines amount
            total, total_currency, iml = inv.compute_invoice_totals(company_currency, iml)

            name = inv.name or ''
            if inv.payment_term_id:
                # totlines = inv.payment_term_id.with_context(currency_id=inv.currency_id.id).compute(total, date_invoice)[0]
                totlines = inv.payment_term_id.with_context(currency_id=company_currency.id).compute(total, inv.date_invoice)[0]
                res_amount_currency = total_currency
                # ctx['date'] = date_invoice
                for i, t in enumerate(totlines):
                    if inv.currency_id != company_currency:
                        amount_currency = company_currency._convert(t[1], inv.currency_id, inv.company_id, inv._get_currency_rate_date() or fields.Date.today())
                    else:
                        amount_currency = False

                    # last line: add the diff
                    res_amount_currency -= amount_currency or 0
                    if i + 1 == len(totlines):
                        amount_currency += res_amount_currency

                    iml.append({
                        'type': 'dest',
                        'name': name,
                        'price': t[1],
                        'account_id': inv.account_id.id,
                        'date_maturity': t[0],
                        'amount_currency': diff_currency and amount_currency,
                        'currency_id': diff_currency and inv.currency_id.id,
                        'invoice_id': inv.id
                    })
            else:
                iml.append({
                    'type': 'dest',
                    'name': name,
                    'price': total,
                    'account_id': inv.account_id.id,
                    'date_maturity': inv.date_due,
                    'amount_currency': diff_currency and total_currency,
                    'currency_id': diff_currency and inv.currency_id.id,
                    'invoice_id': inv.id
                })
            part = self.env['res.partner']._find_accounting_partner(inv.partner_id)
            line = [(0, 0, self.line_get_convert(l, part.id)) for l in iml]
            if self.applied_disc:
                if inv.currency_id != company_currency:
                    # currency = inv.currency_id.with_context(date=inv.date_invoice or fields.Date.context_today(self))
                    # discount_amount_currency = company_currency.compute(self.applied_disc, inv.currency_id)
                    # discount_amount = currency.round(self.applied_disc)
                    currency = inv.currency_id
                    date = self._get_currency_rate_date() or fields.Date.context_today(self)
                    discount_amount_currency = currency._convert(self.applied_disc, company_currency, inv.company_id, date)
                    discount_amount = currency.round(self.applied_disc)
                else:
                    discount_amount_currency = False
                    discount_amount = inv.currency_id.round(self.applied_disc)
                line.append((0,0,{
                'date_maturity':  False,
                'partner_id': part.id,
                'name': 'Discount',
                'debit': discount_amount,
                'credit': 0,
                'account_id': inv.account_id.id,
                'analytic_lines': [],
                'amount_currency': diff_currency and discount_amount_currency,
                'currency_id': diff_currency and inv.currency_id.id,
                'tax_code_id':  False,
                'tax_amount': False,
                'ref': "DISC REF",
                'quantity': 1.00,
                'product_id': False,
                'product_uom_id':False,
                'analytic_account_id': False,
                'state':'valid',
            }))
            
            line = inv.group_lines(iml, line)

            # journal = inv.journal_id.with_context(ctx)
            line = inv.finalize_invoice_move_lines(line)

            date = inv.date or inv.date_invoice
            move_vals = {
                'ref': inv.reference,
                'line_ids': line,
                'journal_id': inv.journal_id.id,
                'date': date,
                'narration': inv.comment,
            }
            move = account_move.create(move_vals)
            # Pass invoice in context in method post: used if you want to get the same
            # account move reference when creating the same invoice after a cancelled one:
            move.post(invoice = inv)
            # make the invoice point to that move
            vals = {
                'move_id': move.id,
                'date': date,
                'move_name': move.name,
            }
            inv.write(vals)
        return True

class AccountInvoiceLine(models.Model):
    _inherit = "account.invoice.line"

    @api.one
    @api.depends('price_unit', 'discount', 'invoice_line_tax_ids', 'quantity',
        'product_id', 'invoice_id.partner_id', 'invoice_id.currency_id', 'invoice_id.company_id', 
        'invoice_id.date_invoice', 'invoice_id.date', 'invoice_id.discount_amt')
    def _compute_price(self):
        currency = self.invoice_id and self.invoice_id.currency_id or None
        price = self.price_unit * (1 - (self.discount or 0.0) / 100.0)
        price1 = (self.price_unit * (1 - (self.discount or 0.0) / 100.0)) * (1 - (self.invoice_id.discount_amt or 0.0) / 100.0)
        taxes = False
        if self.invoice_line_tax_ids:
            taxes = self.invoice_line_tax_ids.compute_all(price, currency, self.quantity, product=self.product_id, partner=self.invoice_id.partner_id)
            taxes1 = self.invoice_line_tax_ids.compute_all(price1, currency, self.quantity, product=self.product_id, partner=self.invoice_id.partner_id)
        if self.invoice_id.discount_amt > 0:
            self.price_subtotal = price_subtotal_signed = taxes['total_excluded'] if taxes else self.quantity * price
            self.total_with_global_disc = price_subtotal_signed = taxes1['total_excluded'] if taxes else self.quantity * price
        else:
            self.price_subtotal = price_subtotal_signed = taxes['total_excluded'] if taxes else self.quantity * price
        if self.invoice_id.currency_id and self.invoice_id.currency_id != self.invoice_id.company_id.currency_id:
            currency = self.invoice_id.currency_id
            date = self.invoice_id._get_currency_rate_date()
            price_subtotal_signed = currency._convert(price_subtotal_signed, self.invoice_id.company_id.currency_id, self.company_id or self.env.user.company_id, date or fields.Date.today())
            # price_subtotal_signed = self.invoice_id.currency_id.compute(price_subtotal_signed, self.invoice_id.company_id.currency_id)
        sign = self.invoice_id.type in ['in_refund', 'out_refund'] and -1 or 1
        self.price_subtotal_signed = price_subtotal_signed * sign

    total_with_global_disc = fields.Float('Total With Global Disc', compute="_compute_price", store=True)

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4
