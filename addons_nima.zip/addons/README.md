# Nima PFAU odoo12

Migrate qweb reports and custom module from odoo11 to odoo 12