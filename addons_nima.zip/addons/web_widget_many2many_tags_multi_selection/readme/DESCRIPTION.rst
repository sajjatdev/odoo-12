In a many2many_tags widget when a lot of entries should be selected it's fastidious to select 80% of them. Then you may click on 'search more', but impossible to select several attributes at once.

This module adds a checkbox to this list so multiple entries can be selected at once.
