After installation, the behavior of all fields using the 'many2many_tags' widget will be changed automatically.
