# -*- coding: utf-8 -*-

{
    'name': "Sale Product Configuration Custom",
    'description': """
Sale Product Configuration Custom.
==================================
        """,
    'category': 'sale',
    'version': '0.1',
    'depends': ['sale'],
    'data': [
        'views/assets.xml',
    ],
}
