# -*- coding: utf-8 -*-
from odoo import http

# class PfauCustomFields(http.Controller):
#     @http.route('/pfau_custom_fields/pfau_custom_fields/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/pfau_custom_fields/pfau_custom_fields/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('pfau_custom_fields.listing', {
#             'root': '/pfau_custom_fields/pfau_custom_fields',
#             'objects': http.request.env['pfau_custom_fields.pfau_custom_fields'].search([]),
#         })

#     @http.route('/pfau_custom_fields/pfau_custom_fields/objects/<model("pfau_custom_fields.pfau_custom_fields"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('pfau_custom_fields.object', {
#             'object': obj
#         })