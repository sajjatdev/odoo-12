# -*- coding: utf-8 -*-

from odoo import models, fields, api

class CustomProductTemplate(models.Model):
    _inherit = 'product.template'

    length = fields.Char(string="Length")
    width = fields.Char(string="Width")
    height = fields.Char(string="Height")
    seating_height = fields.Char(string="Seating Height")
    designer = fields.Char(string="Designer")
    # partner_id = fields.Many2one(comodel_name="res.partner", string="Vendor Name", domain=[('supplier', '=', True)])


class CustomResPartner(models.Model):
    _inherit = 'res.partner'

    vendor_discount = fields.Float(string="Discount", digits=(14,2))



class CustomCrmLead(models.Model):
    _inherit = "crm.lead"

    office_company_id = fields.Many2one(comodel_name="res.partner", string="Company", 
                            help="Company, who builds/rents a new office")
    office_company_contact_id = fields.Many2one(comodel_name="res.partner", string="Company Contact Person", 
                            help="Company contact person, who is managing the new office project")
    architect_office_id = fields.Many2one(comodel_name="res.partner", string="Architect Office", 
                            help="Architect Office")
    architect_contact_person_id = fields.Many2one(comodel_name="res.partner", string="Architect Contact Person", 
                            help="Architect Contact Person")
    construction_company_id = fields.Many2one(comodel_name="res.partner", string="Construction Company", 
                            help="Construction Company")


    @api.multi
    def _convert_opportunity_data(self, customer, team_id=False):
        """ orverridden the method to update lead's custom field data to opportunity record
        """
        if not team_id:
            team_id = self.team_id.id if self.team_id else False
        value = {
            'planned_revenue': self.planned_revenue,
            'probability': self.probability,
            'name': self.name,
            'partner_id': customer.id if customer else False,
            'type': 'opportunity',
            'date_open': fields.Datetime.now(),
            'email_from': customer and customer.email or self.email_from,
            'phone': customer and customer.phone or self.phone,
            'date_conversion': fields.Datetime.now(),
            'office_company_id': self.office_company_id.id,
            'office_company_contact_id': self.office_company_contact_id.id,
            'architect_office_id': self.architect_office_id.id,
            'architect_contact_person_id': self.architect_contact_person_id.id,
            'construction_company_id': self.construction_company_id.id,
        }
        if not self.stage_id:
            stage = self._stage_find(team_id=team_id)
            value['stage_id'] = stage.id
            if stage:
                value['probability'] = stage.probability
        return value