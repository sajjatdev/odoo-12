# -*- coding: utf-8 -*-
{
    'name': "PFAU Custom Fields",

    'summary': """
        Adds custom fields to Product, Vendor, Pipeline/Lead forms etc.""",

    'description': """
        Adds custom fields to Product, Vendor, Pipeline/Lead forms etc.
    """,

    'author': "Linescripts Softwares",
    'website': "http://www.linescripts.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/master/odoo/addons/base/module/module_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base', 'crm', 'sale', 'purchase'],

    # always loaded
    'data': [
        # 'security/ir.model.access.csv',
        'views/views.xml',
        'views/templates.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
}